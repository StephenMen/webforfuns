// Replace your existing GhostMountain() function with this one.
// Uses the constants already in your file: KRAMA_IMG, IMG_2, IMG_5.
// Needs: import { useEffect, useRef, useState } from 'react';  (you already have it)

// Upload boy.png next to your other images on GitHub (or put it in /public and use '/boy.png')
const BOY_IMG = 'https://raw.githubusercontent.com/StephenMen/webforfuns/main/boy.png';

function GhostMountain() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const page1Ref = useRef<HTMLDivElement>(null);
  const page2Ref = useRef<HTMLDivElement>(null);
  const kramaLRef = useRef<HTMLDivElement>(null);
  const kramaRRef = useRef<HTMLDivElement>(null);
  const innerLRef = useRef<HTMLDivElement>(null);
  const innerRRef = useRef<HTMLDivElement>(null);
  const ctxRef = useRef<gsap.Context | null>(null);
  const busyRef = useRef(false);
  const pageRef = useRef(0);
  const [currentPage, setCurrentPage] = useState(0);

  const TILT_L = -15; // left krama leans up to the right
  const TILT_R = 15;  // right krama leans up to the left

  const goTo = (to: number) => {
    if (busyRef.current || to === pageRef.current) return;
    const section = sectionRef.current;
    const p1 = page1Ref.current;
    const p2 = page2Ref.current;
    const kL = kramaLRef.current;
    const kR = kramaRRef.current;
    const iL = innerLRef.current;
    const iR = innerRRef.current;
    if (!section || !p1 || !p2 || !kL || !kR || !iL || !iR) return;

    busyRef.current = true;
    const fwd = to === 1;
    const from = fwd ? p1 : p2;
    const into = fwd ? p2 : p1;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const finish = () => {
      gsap.set(kR, { zIndex: 1 });
      pageRef.current = to;
      setCurrentPage(to);
      busyRef.current = false;
    };

    ctxRef.current?.add(() => {
      // Distances needed to push things fully off the section's edges
      const sr = section.getBoundingClientRect();
      const pr = from.getBoundingClientRect();
      const pageOutLeft = -(pr.right - sr.left) - 40;
      const pageOutRight = sr.right - pr.left + 40;
      const leftKramaOut = -(kL.getBoundingClientRect().right - sr.left) - 20;
      const rightKramaOut = -(kR.getBoundingClientRect().right - sr.left) - 20;
      const boyWrap = section.querySelector('.gm-boy-wrap');

      if (reduce) {
        gsap.set(from, { autoAlpha: 0, x: 0 });
        gsap.set(into, { autoAlpha: 1, x: 0 });
        if (fwd) gsap.set(boyWrap, { autoAlpha: 1, xPercent: 0 });
        gsap.set(iL, { x: fwd ? leftKramaOut : 0 });
        gsap.set(iR, { x: fwd ? rightKramaOut : 0 });
        finish();
        return;
      }

      const tl = gsap.timeline({ onComplete: finish });
      tl.set(kR, { zIndex: 6 }, 0); // travelling krama passes in front of the pages

      if (fwd) {
        tl
          // right krama travels right to left, straightening up so the whole ribbon shows
          .to(iR, { x: rightKramaOut, duration: 2.2, ease: 'power2.inOut' }, 0)
          .to(iR, { rotation: -3, duration: 2.2, ease: 'none' }, 0)
          .to(iR, { scale: 1.18, duration: 1.1, ease: 'sine.inOut', yoyo: true, repeat: 1 }, 0)
          // page 1 and the left krama leave to the left
          .to(from, { x: pageOutLeft, duration: 1.0, ease: 'power2.in' }, 0.25)
          .to(iL, { x: leftKramaOut, duration: 0.9, ease: 'power2.in' }, 0.25)
          // page 2 follows in from the right
          .set(into, { autoAlpha: 1, x: pageOutRight }, 0)
          .to(into, { x: 0, duration: 1.2, ease: 'power3.out' }, 0.9)
          // the boy arrives a beat after the page, so he feels like he is in front of it
          .fromTo(boyWrap, { xPercent: 22, autoAlpha: 0 }, { xPercent: 0, autoAlpha: 1, duration: 1.4, ease: 'power3.out' }, 1.1)
          .set(from, { autoAlpha: 0, x: 0 }, 1.3);
      } else {
        tl
          // right krama travels back left to right and settles half off the right edge
          .to(iR, { x: 0, duration: 2.2, ease: 'power2.inOut' }, 0)
          .to(iR, { rotation: TILT_R, duration: 2.2, ease: 'none' }, 0)
          .to(iR, { scale: 1.18, duration: 1.1, ease: 'sine.inOut', yoyo: true, repeat: 1 }, 0)
          // page 2 leaves to the right, page 1 comes back in from the left
          .to(from, { x: pageOutRight, duration: 1.0, ease: 'power2.in' }, 0.25)
          .set(into, { autoAlpha: 1, x: pageOutLeft }, 0)
          .to(into, { x: 0, duration: 1.2, ease: 'power3.out' }, 0.9)
          .to(iL, { x: 0, duration: 1.1, ease: 'power3.out' }, 1.0)
          .set(from, { autoAlpha: 0, x: 0 }, 1.3);
      }
    });
  };

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      // Starting lean of each krama
      gsap.set('.gm-krama-left .gm-krama-inner', { rotation: TILT_L });
      gsap.set('.gm-krama-right .gm-krama-inner', { rotation: TILT_R });

      // They slide in from their edges as the section scrolls into view
      const st = { trigger: section, start: 'top 80%', end: 'top 40%', scrub: 1 };
      gsap.fromTo('.gm-krama-left', { xPercent: -30, autoAlpha: 0 }, { xPercent: 0, autoAlpha: 1, ease: 'power3.out', scrollTrigger: st });
      gsap.fromTo('.gm-krama-right', { xPercent: 30, autoAlpha: 0 }, { xPercent: 0, autoAlpha: 1, ease: 'power3.out', scrollTrigger: st });

      // Slow idle sway
      if (!reduce) {
        gsap.to('.gm-krama-left', { rotation: 1.2, duration: 3.4, ease: 'sine.inOut', yoyo: true, repeat: -1 });
        gsap.to('.gm-krama-right', { rotation: -1.2, duration: 3.9, ease: 'sine.inOut', yoyo: true, repeat: -1 });
      }

      // Page 1 content entrance
      gsap.fromTo(
        '.page-1-content > *',
        { autoAlpha: 0, y: 50 },
        {
          autoAlpha: 1, y: 0, stagger: 0.2, ease: 'power3.out',
          scrollTrigger: { trigger: section, start: 'top 70%', end: 'top 30%', scrub: 1 },
        }
      );

      // Boy portrait on page 2: starts hidden, then two layers drift at different speeds as you scroll
      gsap.set('.gm-boy-wrap', { autoAlpha: 0 });
      const par = { trigger: section, start: 'top bottom', end: 'bottom top', scrub: 1 };
      gsap.fromTo('.gm-boy', { yPercent: 9 }, { yPercent: -9, ease: 'none', scrollTrigger: par });
      gsap.fromTo('.gm-boy-bg', { yPercent: -5, scale: 1.12 }, { yPercent: 5, scale: 1, ease: 'none', scrollTrigger: par });
      if (!reduce) {
        gsap.to('.gm-boy', { scale: 1.02, duration: 4.5, ease: 'sine.inOut', yoyo: true, repeat: -1 });
      }
    }, sectionRef);

    ctxRef.current = ctx;
    return () => {
      ctx.revert();
      ctxRef.current = null;
    };
  }, []);

  return (
    <section className="gm-section" id="ghost-mountain" ref={sectionRef}>
      {/* Krama leaning in from each side edge */}
      <div className="gm-krama gm-krama-left" ref={kramaLRef} aria-hidden="true">
        <div className="gm-krama-inner" ref={innerLRef}>
          <img src={KRAMA_IMG} alt="" />
        </div>
      </div>
      <div className="gm-krama gm-krama-right" ref={kramaRRef} aria-hidden="true">
        <div className="gm-krama-inner" ref={innerRRef}>
          <img src={KRAMA_IMG} alt="" />
        </div>
      </div>

      {/* Both pages share one grid cell, so the section is always as tall as the taller page */}
      <div className="gm-stage">
        {/* Page 1: History */}
        <div className="gm-page gm-page-1" ref={page1Ref}>
          <div className="editorial-inner page-1-content">
            <div className="editorial-left">
              <div className="gm-text">
                <div className="section-label">The History</div>
                <h2 className="section-title">Ghost Mountain</h2>
                <div className="section-body">
                  <p>Phnum Khmoch, known as "Ghost Mountain," sits along the Thai-Cambodian border — a place where history and horror converge. During the Khmer Rouge regime (1975-1979), this remote region became a site of systematic violence.</p>
                  <p>The mountain's dense jungles concealed mass graves, execution sites, and forced labor camps. Thousands were brought here from across the country, their fates sealed by a regime that sought to erase an entire generation.</p>
                  <p>Today, the land still yields bones during the rainy season. The trees grow from burial sites. The earth remembers what the world tried to forget.</p>
                </div>
              </div>
            </div>
            <div className="editorial-right">
              <div className="gm-image">
                <img src={IMG_2} alt="Ghost Mountain" className="framed-image" />
              </div>
              <div className="gm-doc-wrap">
                <div className="gm-doc">
                  <div className="doc-header">Historical Record</div>
                  <strong>1975-1979</strong><br />
                  Border region<br />
                  Mass graves identified
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Page 2: Synopsis */}
        <div className="gm-page gm-page-2" ref={page2Ref}>
          <div className="editorial-inner page-2-content">
            <div className="editorial-left">
              <div className="gm-text">
                <div className="section-label">Film Synopsis</div>
                <h2 className="section-title">Blood Border</h2>
                <div className="section-body">
                  <p>In the shadow of the Thai-Cambodian border lies Phnum Khmoch — Ghost Mountain — where the earth still holds secrets buried for decades. <em>Blood Border</em> is a harrowing documentary that unearths the untold story of a second killing field, hidden from the world's gaze.</p>
                  <p>Through intimate survivor testimonies, archaeological discoveries, and haunting archival footage, the film follows investigators as they excavate mass graves and piece together evidence of systematic atrocities committed during the final days of the Khmer Rouge regime.</p>
                  <p>As bones emerge from the jungle floor and witnesses break decades of silence, the documentary reveals not just a historical tragedy, but an ongoing quest for justice that continues to shape Cambodia's fragile present.</p>
                  <p style={{ marginTop: '20px', fontStyle: 'italic', opacity: 0.7 }}>A film about memory, evidence, and the weight of what the world chose to forget.</p>
                </div>
              </div>
            </div>
            <div className="editorial-right">
              <div className="gm-boy-wrap">
                <div className="gm-boy-bg">
                  <img src={IMG_5} alt="" />
                </div>
                <img className="gm-boy" src={BOY_IMG} alt="Portrait of a young boy" />
              </div>
              <div className="gm-doc-wrap">
                <div className="gm-doc">
                  <div className="doc-header">Film Details</div>
                  <strong>Documentary</strong><br />
                  Runtime: 95 min<br />
                  Language: Khmer/English<br />
                  Year: 2025
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="gm-nav">
        <button className={`gm-nav-btn ${currentPage === 0 ? 'active' : ''}`} aria-pressed={currentPage === 0} onClick={() => goTo(0)}>
          <span className="gm-nav-num">01</span>
          <span className="gm-nav-label">History</span>
        </button>
        <div className="gm-nav-divider"></div>
        <button className={`gm-nav-btn ${currentPage === 1 ? 'active' : ''}`} aria-pressed={currentPage === 1} onClick={() => goTo(1)}>
          <span className="gm-nav-num">02</span>
          <span className="gm-nav-label">Synopsis</span>
        </button>
      </div>

      <button className="gm-arrow-btn" onClick={() => goTo(currentPage === 0 ? 1 : 0)}>
        {currentPage === 0 ? (
          <>
            <span>Read Synopsis</span>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </>
        ) : (
          <>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            <span>Back to History</span>
          </>
        )}
      </button>
    </section>
  );
}
